const express = require('express');
const sql = require('msnodesqlv8');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

function connectToDatabase() {
  const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

  sql.open(connString, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    app.post('/addCustomer', (req, res) => {
      getLastCustomerID()
        .then((lastCustomerID) => {
          const customer = req.body;
          customer.CustomerID = lastCustomerID + 1;

          addCustomerToDatabase(customer)
            .then(() => {
              res.json({ success: true });
            })
            .catch((error) => {
              console.error('Error occurred while adding customer:', error);
              res.status(500).json({ success: false, error: 'Error occurred while adding customer' });
            });
        })
        .catch((error) => {
          console.error('Error occurred while getting last customer ID:', error);
          res.status(500).json({ success: false, error: 'Error occurred while getting last customer ID' });
        });
    });

    app.listen(port, () => {
      console.log(`Listening on http://localhost:${port}`);
    });
  });
}

function getLastCustomerID() {
  return new Promise((resolve, reject) => {
    const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

    sql.open(connString, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(CustomerID) AS lastCustomerID FROM Customer';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastCustomerID = results[0].lastCustomerID || 0;
            resolve(lastCustomerID);
          }
          conn.close();
        });
      }
    });
  });
}

function addCustomerToDatabase(customer) {
  return new Promise((resolve, reject) => {
    const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

    sql.open(connString, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
          INSERT INTO Customer (CustomerID, Name, Telephone, Request)
          VALUES (${customer.CustomerID}, '${customer.Name}', '${customer.Telephone}', '${customer.Request}')
        `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('Customer added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}

connectToDatabase();
