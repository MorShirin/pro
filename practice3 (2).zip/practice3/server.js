const express = require('express');
const sql = require('msnodesqlv8');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

function connectToDatabase() {
  const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

  sql.open(connString, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    app.post('/checkRequest', (req, res) => {
      const customerCode = req.body.code;

      const query = `
        SELECT Request
        FROM Customer
        WHERE CustomerID = '${customerCode}'
      `;

      conn.query(query, (err, results) => {
        if (err) {
          console.error(`Error executing query: ${err}`);
          return res.status(500).json({ success: false, error: 'Error occurred while fetching customer data' });
        }

        if (results.length === 0) {
          console.log('Invalid customer code');
          return res.status(404).json({ success: false, error: 'Invalid customer code' });
        }

        const request = results[0].Request;
        console.log(`Customer request: ${request}`);

        // Perform relevant actions based on the request (e.g., block irrelevant buttons)
        // ...

        res.json({ success: true, request });
      });
    });

    app.listen(port, () => {
      console.log(`Listening on http://localhost:${port}`);
    });
  });
}

connectToDatabase();
