const express = require('express');
const sql = require('msnodesqlv8');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());
const connStr = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

app.get('/api/customers/:customerId', (req, res) => {
  const customerId = req.params.customerId;
  
  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
  
    const query = `SELECT * FROM Customer WHERE CustomerID = ${customerId}`;
  
    conn.query(query, (err, rows) => {
      if (err) {
        console.error(err);
        conn.close();
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }
  
      if (rows.length > 0) {
        const customer = rows[0];
        res.json({ customer });
      } else {
        res.json({ customer: null });
      }
  
      conn.close();
    });
  });
});

function connectCustomerToDatabase() {

  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    // Check if DateTimeAdded column exists in Customer table
    const checkColumnQuery = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'DateTimeAdded'
    `;

    conn.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error(`Error executing query: ${err}`);
      } else {
        if (results.length === 0) {
          // DateTimeAdded column doesn't exist, add it
          const addDateTimeAddedColumnQuery = `
            ALTER TABLE Customer
            ADD DateTimeAdded DATETIME;
          `;

          conn.query(addDateTimeAddedColumnQuery, (err) => {
            if (err) {
              console.error(`Error executing query: ${err}`);
            } else {
              console.log('Added DateTimeAdded column to Customer table');
            }
          });
        } else {
          console.log('DateTimeAdded column already exists in Customer table');
        }
      }
    });

    app.post('/addCustomer', (req, res) => {
      getLastCustomerID()
        .then((lastCustomerID) => {
          const customer = req.body;
          customer.CustomerID = lastCustomerID + 1;

          addCustomerToDatabase(customer)
            .then(() => {
              res.json({ success: true });
            })
            .catch((error) => {
              console.error('Error occurred while adding customer:', error);
              res.status(500).json({ success: false, error: 'Error occurred while adding customer' });
            });
        })
        .catch((error) => {
          console.error('Error occurred while getting last customer ID:', error);
          res.status(500).json({ success: false, error: 'Error occurred while getting last customer ID' });
        });
    });
  });
}

function getLastCustomerID() {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(CustomerID) AS lastCustomerID FROM Customer';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastCustomerID = results[0].lastCustomerID || 0;
            resolve(lastCustomerID);
          }
          conn.close();
        });
      }
    });
  });
}

function addCustomerToDatabase(customer) {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
          INSERT INTO Customer (CustomerID, Name, Telephone, Request, DateTimeAdded)
          VALUES (${customer.CustomerID}, '${customer.Name}', '${customer.Telephone}', '${customer.Request}', GETDATE())
        `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('Customer added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}
app.get('/api/assets/:assetId', (req, res) => {
  const assetId = req.params.assetId;
  
  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
  
    const query = `SELECT AssetID,Worth,AssetDesc FROM Asset WHERE AssetID = ${assetId}`;
  
    conn.query(query, (err, rows) => {
      if (err) {
        console.error(err);
        conn.close();
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }
  
      if (rows.length > 0) {
        const asset = rows[0];
        res.json({ asset });
      } else {
        res.json({ asset: null });
      }
  
      conn.close();
    });
  });
})


function connectAssetToDatabase() {
  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    // Check if DateTimeAdded column exists in Customer table
    const checkColumnQuery = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'Asset' AND COLUMN_NAME = 'DateTimeAdded'
    `;

    conn.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error(`Error executing query: ${err}`);
      } else {
        if (results.length === 0) {
          // DateTimeAdded column doesn't exist, add it
          const addDateTimeAddedColumnQuery = `
            ALTER TABLE Asset
            ADD DateTimeAdded DATETIME;
          `;

          conn.query(addDateTimeAddedColumnQuery, (err) => {
            if (err) {
              console.error(`Error executing query: ${err}`);
            } else {
              console.log('Added DateTimeAdded column to Asset table');
            }
          });
        } else {
          console.log('DateTimeAdded column already exists in Asset table');
        }
      }
    });

app.post('/addAsset', (req, res) => {
  getLastAssetID()
    .then((lastAssetID) => {
      const asset = req.body;
      asset.AssetID = lastAssetID + 1;

      addAssetToDatabase(asset)
        .then(() => {
          res.json({ success: true });
        })
        .catch((error) => {
          console.error('Error occurred while adding asset:', error);
          res.status(500).json({ success: false, error: 'Error occurred while adding asset' });
        });
    })
    .catch((error) => {
      console.error('Error occurred while getting last asset ID:', error);
      res.status(500).json({ success: false, error: 'Error occurred while getting last asset ID' });
    });
  });
});
}

function getLastAssetID() {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(AssetID) AS lastAssetID FROM Asset';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastAssetID = results[0].lastAssetID || 0;
            resolve(lastAssetID);
          }
          conn.close();
        });
      }
    });
  });
}

function addAssetToDatabase(asset) {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
          INSERT INTO Asset(AssetID, AssetDesc, Worth, Address, Floor, Rooms,DateTimeAdded)
          VALUES (${asset.AssetID}, '${asset.AssetDesc}', '${asset.Worth}','${asset.Address}','${asset.Floor}','${asset.Rooms}',GETDATE())
        `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('Asset added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}
function connectMeetToDatabase() {
  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    // Check if DateTimeAdded column exists in Customer table
    const checkColumnQuery = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'Meet' AND COLUMN_NAME = 'DateTimeAdded'
    `;

    conn.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error(`Error executing query: ${err}`);
      } else {
        if (results.length === 0) {
          // DateTimeAdded column doesn't exist, add it
          const addDateTimeAddedColumnQuery = `
            ALTER TABLE Meet
            ADD DateTimeAdded DATETIME;
          `;

          conn.query(addDateTimeAddedColumnQuery, (err) => {
            if (err) {
              console.error(`Error executing query: ${err}`);
            } else {
              console.log('Added DateTimeAdded column to Meet table');
            }
          });
        } else {
          console.log('DateTimeAdded column already exists in Meet table');
        }
      }
    });
app.post('/addMeet', (req, res) => {
  getLastMeetID()
    .then((lastMeetID) => {
      const meet = req.body;
      meet.MeetID = lastMeetID + 1;

      addMeetToDatabase(meet)
        .then(() => {
          res.json({ success: true });
        })
        .catch((error) => {
          console.error('Error occurred while adding meet:', error);
          res.status(500).json({ success: false, error: 'Error occurred while adding meet' });
        });
    })
    .catch((error) => {
      console.error('Error occurred while getting last meet ID:', error);
      res.status(500).json({ success: false, error: 'Error occurred while getting last meet ID' });
    });
  });
});
}

function getLastMeetID() {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(MeetID) AS lastMeetID FROM Meet';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastMeetID = results[0].lastMeetID || 0;
            resolve(lastMeetID);
          }
          conn.close();
        });
      }
    });
  });
}
function addMeetToDatabase(meet) {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
      INSERT INTO Meet(MeetID,MeetDate,MeetHour,EmployeeID,CustomerID,DateTimeAdded)
      VALUES (${meet.MeetID}, '${meet.MeetDate}', '${meet.MeetHour}', '${meet.EmployeeID}', '${meet.CustomerID}',GETDATE())
    `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('meet added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}
function connectDealToDatabase() {
  sql.open(connStr, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    // Check if DateTimeAdded column exists in Customer table
    const checkColumnQuery = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'Deal' AND COLUMN_NAME = 'DateTimeAdded'
    `;

    conn.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error(`Error executing query: ${err}`);
      } else {
        if (results.length === 0) {
          // DateTimeAdded column doesn't exist, add it
          const addDateTimeAddedColumnQuery = `
            ALTER TABLE Deal
            ADD DateTimeAdded DATETIME;
          `;

          conn.query(addDateTimeAddedColumnQuery, (err) => {
            if (err) {
              console.error(`Error executing query: ${err}`);
            } else {
              console.log('Added DateTimeAdded column to Deal table');
            }
          });
        } else {
          console.log('DateTimeAdded column already exists in Deal table');
        }
      }
    });
app.post('/addDeal', (req, res) => {
  getLastDealID()
    .then((lastDealID) => {
      const deal = req.body;
      deal.DealID = lastDealID + 1;

      addDealToDatabase(deal)
        .then(() => {
          res.json({ success: true });
        })
        .catch((error) => {
          console.error('Error occurred while adding deal:', error);
          res.status(500).json({ success: false, error: 'Error occurred while adding deal' });
        });
    })
    .catch((error) => {
      console.error('Error occurred while getting last deal ID:', error);
      res.status(500).json({ success: false, error: 'Error occurred while getting last deal ID' });
    });
  });
});
}

function getLastDealID() {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(DealID) AS lastDealID FROM Deal';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastDealID = results[0].lastDealID || 0;
            resolve(lastDealID);
          }
          conn.close();
        });
      }
    });
  });
}
function addDealToDatabase(deal) {
  return new Promise((resolve, reject) => {
    sql.open(connStr, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
      INSERT INTO Deal(DealID, DateDeal,TypeDeal,EmployeeID,CustomerID,DateTimeAdded)
      VALUES (${deal.DealID}, '${deal.DateDeal}', '${deal.TypeDeal}', '${deal.EmployeeID}', '${deal.CustomerID}',GETDATE())
    `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('deal added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}
app.listen(port, () => {
  console.log(`Listening on http://localhost:${port}`);
});

connectCustomerToDatabase()
connectAssetToDatabase()
connectMeetToDatabase()
connectDealToDatabase()
