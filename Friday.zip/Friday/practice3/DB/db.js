const sql = require('msnodesqlv8');

async function connectToDatabase(server, database, username, password, port) {
  try {
    const connectionString = `server=${server},${port};Database=${database};User Id=${username};Password=${password};`;
    await sql.open(connectionString);
    console.log('Successfully connected to the database!');
  } catch (err) {
    throw new Error(`Failed to connect to the database: ${err}`);
  }
}

// Example usage
const server = 'DESKTOP-59735SK';
const database = 'D';
const username = 'DESKTOP-59735SK\מור שירין';
const password = '';
const port = 1434;

connectToDatabase(server, database, username, password, port)
  .then(() => {
    const query = 'SELECT * FROM Assets';
    return sql.query(query);
  })
  .then((result) => {
    const records = result;
    if (records.length > 0) {
      records.forEach((record) => {
        console.log(record);
      });
    } else {
      console.log('No records found');
    }
    sql.close();
  })
  .catch((err) => {
    console.error(`Error: ${err}`);
  });
