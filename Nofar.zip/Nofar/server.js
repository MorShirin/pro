const express = require('express');
const sql = require('msnodesqlv8');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.json());

function connectToDatabase() {
  const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

  sql.open(connString, (err, conn) => {
    if (err) {
      console.error(`Failed to connect to the database: ${err}`);
      throw err;
    }
    console.log('Successfully connected to the database!');

    // Check if DateTimeAdded column exists in Customer table
    const checkColumnQuery = `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'Customer' AND COLUMN_NAME = 'DateTimeAdded'
    `;

    conn.query(checkColumnQuery, (err, results) => {
      if (err) {
        console.error(`Error executing query: ${err}`);
      } else {
        if (results.length === 0) {
          // DateTimeAdded column doesn't exist, add it
          const addDateTimeAddedColumnQuery = `
            ALTER TABLE Customer
            ADD DateTimeAdded DATETIME;
          `;

          conn.query(addDateTimeAddedColumnQuery, (err) => {
            if (err) {
              console.error(`Error executing query: ${err}`);
            } else {
              console.log('Added DateTimeAdded column to Customer table');
            }
          });
        } else {
          console.log('DateTimeAdded column already exists in Customer table');
        }
      }
    });

    app.post('/addCustomer', (req, res) => {
      getLastCustomerID()
        .then((lastCustomerID) => {
          const customer = req.body;
          customer.CustomerID = lastCustomerID + 1;

          addCustomerToDatabase(customer)
            .then(() => {
              res.json({ success: true });
            })
            .catch((error) => {
              console.error('Error occurred while adding customer:', error);
              res.status(500).json({ success: false, error: 'Error occurred while adding customer' });
            });
        })
        .catch((error) => {
          console.error('Error occurred while getting last customer ID:', error);
          res.status(500).json({ success: false, error: 'Error occurred while getting last customer ID' });
        });
    });

    app.listen(port, () => {
      console.log(`Listening on http://localhost:${port}`);
    });
  });
}

function getLastCustomerID() {
  return new Promise((resolve, reject) => {
    const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

    sql.open(connString, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const sqlQuery = 'SELECT MAX(CustomerID) AS lastCustomerID FROM Customer';
        conn.query(sqlQuery, (err, results) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            const lastCustomerID = results[0].lastCustomerID || 0;
            resolve(lastCustomerID);
          }
          conn.close();
        });
      }
    });
  });
}

function addCustomerToDatabase(customer) {
  return new Promise((resolve, reject) => {
    const connString = 'Driver={SQL Server Native Client 11.0};Server=DESKTOP-KTJIMBM;Database=DB;Trusted_Connection=yes;';

    sql.open(connString, (err, conn) => {
      if (err) {
        reject(`Failed to connect to the database: ${err}`);
      } else {
        const query = `
          INSERT INTO Customer (CustomerID, Name, Telephone, Request, DateTimeAdded)
          VALUES (${customer.CustomerID}, '${customer.Name}', '${customer.Telephone}', '${customer.Request}', GETDATE())
        `;
        conn.query(query, (err) => {
          if (err) {
            reject(`Error executing query: ${err}`);
          } else {
            console.log('Customer added successfully!');
            resolve();
          }
          conn.close();
        });
      }
    });
  });
}

connectToDatabase();
