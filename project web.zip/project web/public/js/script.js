const fetchFunction = (html) => {
    fetch(html)
        .then(response => response.text())
        .then(htmlContent => {
            document.getElementById('body').innerHTML = htmlContent;
        });
}

async function fetchFlight() {
    const response = await fetch('/flight');
    const data = await response.json();

    const flightList = document.getElementById('flightList');
    flightList.innerHTML = ``;
    let flight = ''; 

    data.forEach((flight) => {
        flight += `<tr>
            <td> ${flight.destination}</td>
            <td>${flight.origin}</td>
            <td> ${flight.date}</td>
            <td>${flight.hour}</td>
            <td> ${flight.terminal}</td>
            <td> ${flight.price}</td>
        </tr>`;
    });

    console.log(flight);
    flightList.innerHTML = flight;
}

async function addNewFlight() {
    event.preventDefault(); // Prevent the default form submission behavior

    // Get the form data
    const destination = document.getElementById('destination').value;
    const origin = document.getElementById('origin').value;
    const date = document.getElementById('date').value;
    const hour = document.getElementById('hour').value;
    const terminal = document.getElementById('terminal').value;
    const price = document.getElementById('price').value;

    // Create the flight object
    const flight = {
        destination,
        origin,
        date,
        hour,
        terminal,
        price
    };

    try {
        const response = await fetch('/flight', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(flight),
        });

        if (response.ok) {
            // Flight added successfully, show a message or update the flight list
            console.log('Flight added successfully!');
            fetchFlight(); // Fetch the updated flight list
        } else {
            console.error('Failed to add flight:', response.statusText);
        }
    } catch (error) {
        console.error('Error adding flight:', error);
    }
}

// Event listener to handle form submission
document.getElementById('flightForm').addEventListener('submit', addNewFlight);

// Function to fetch flights from the server and display them in the table
async function fetchFlight() {
    const response = await fetch('/flight');
    const data = await response.json();

    const flightList = document.getElementById('flightList');
    flightList.innerHTML = '';

    data.forEach((flight) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${flight.destination}</td>
            <td>${flight.origin}</td>
            <td>${flight.date}</td>
            <td>${flight.hour}</td>
            <td>${flight.terminal}</td>
            <td>${flight.price}</td>
        `;
        flightList.appendChild(row);
    });
}

// Fetch flights when the page loads
fetchFlight();


// Call the createSparkles function when the page loads

async function fetchOpinion() {
    const response = await fetch('/opinion');
    const data = await response.json();

    const opinionList = document.getElementById('opinionList');
    opinionList.innerHTML = ``;
    let opinion = ''; 

    data.forEach((opinion) => {
        opinion += `<tr>
            <td> ${opinion.name}</td>
            <td>${opinion.email}</td>
            <td> ${opinion.subject}</td>
            <td>${opinion.message}</td>

        </tr>`;
    });

    console.log(opinion);
    opinionList.innerHTML = opinion;
}

async function addNewOpinion() {
    event.preventDefault(); // Prevent the default form submission behavior

    // Get the form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;


    // Create the opinion object
    const opinion = {
        name,
        email,
        subject,
        message
    };

    try {
        const response = await fetch('/opinion', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(opinion),
        });

        if (response.ok) {
            // opinion added successfully, show a message or update the opinion list
            console.log('opinion added successfully!');
            fetchOpinion(); // Fetch the updated opinion list
        } else {
            console.error('Failed to add opinion:', response.statusText);
        }
    } catch (error) {
        console.error('Error adding opinion:', error);
    }
}

// Event listener to handle form submission
document.getElementById('opinionForm').addEventListener('submit', addNewOpinion);

// Function to fetch flights from the server and display them in the table
async function fetchOpinion() {
    const response = await fetch('/opinion');
    const data = await response.json();

    const opinionList = document.getElementById('opinionList');
    opinionList.innerHTML = '';

    data.forEach((opinion) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${opinion.name}</td>
            <td>${opinion.email}</td>
            <td>${opinion.subject}</td>
            <td>${opinion.message}</td>

        `;
        opinionList.appendChild(row);
    });
}
fetchOpinion();

async function searchFlights() {
    const destinationInput = document.getElementById('destination');
    const destination = destinationInput.value;

    const response = await fetch('/flight');
    const data = await response.json();

    const flightList = document.getElementById('flightList');
    flightList.innerHTML = '';

    data.forEach((flight) => {
        if (flight.destination === destination) {
            const row = document.createElement('tr');
            row.innerHTML = `
            <td>${flight.destination}</td>
            <td>${flight.origin}</td>
            <td>${flight.date}</td>
            <td>${flight.hour}</td>
            <td>${flight.terminal}</td>
            <td>${flight.price}</td>
            `;
            flightList.appendChild(row);
        }
    });

    destinationInput.value = '';
}
async function discountFlight() {
    const response = await fetch('/flight');
    const data = await response.json();
  
    const discount = parseFloat(document.getElementById('discount').value);
  
    const flightList = document.getElementById('flightList');
    flightList.innerHTML = '';
  
    data.forEach((flight) => {
      const discountedPrice = flight.price*(1-discount);
      flightList.innerHTML += `<tr>
          <td>${flight.destination}</td>
          <td>${flight.origin}</td>
          <td>${flight.date}</td>
          <td>${flight.hour}</td>
          <td>${flight.terminal}</td>
          <td>${discountedPrice}</td>
      </tr>`;
    });
  }
  
  discountFlight();

  async function applyDiscount() {
    const specific = document.getElementById('destination-specific').value;
    const discount = parseFloat(document.getElementById('discount').value);
    
    const flightList = document.getElementById('flightList');
    flightList.innerHTML = '';
    
    const response = await fetch('/flight');
    const data = await response.json();
  
    data.forEach((flight) => {
      if (flight.destination === specific) {
        const discountedPrice = flight.price * (1 - discount);
        flightList.innerHTML += `<tr>
        <td>${flight.destination}</td>
        <td>${flight.origin}</td>
        <td>${flight.date}</td>
        <td>${flight.hour}</td>
        <td>${flight.terminal}</td>
        <td>${discountedPrice}</td>
    </tr>`;
    }
});
}

applyDiscount();
// morshirin23
// 59daJAH20rHceGRF