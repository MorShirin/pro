const express = require('express');
const app = express();
const port = 3001;
const {getFlight} = require('./model/mongoDB')

// Serve static files from the 'public' directory
app.use(express.static('public'));

app.get('/flight', async (req, res) => {
    const flight = await getFlight()
    res.json(flight)
})

function addFlightToDatabase(flight) {
    return new Promise(async (resolve, reject) => {
      const db = await connectToDB();
      const flightCollection = db.collection('flight'); // שם הקולקציה שבה תרצה לשמור את הנתונים
  
      const flight = { 
        destination: flight.destination, 
        origin: flight.origin, 
        date: flight.date, 
        hour: flight.hour, 
        terminal: flight.terminal };


  
      flightCollection.insertOne(flight, (err, result) => {
        if (err) {
          console.error('Error executing query:', err);
          reject('Error occurred while adding flight');
        } else {
          console.log('Flight added successfully!');
          resolve();
        }
      });
    });
  }
  

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

addFlightToDatabase(flight)