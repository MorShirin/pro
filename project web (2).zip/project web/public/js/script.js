const fetchFunction = (html) => {
    fetch(html)
        .then(response => response.text())
        .then(htmlContent => {
            document.getElementById('body').innerHTML = htmlContent;
        });
}

async function fetchFlight() {
    const response = await fetch('/flight');
    const data = await response.json();

    const flightList = document.getElementById('flightList');
    flightList.innerHTML = ``;
    let flight = ''; 

    data.forEach((flight) => {
        flight += `<tr>
            <td> ${flight.destination}</td>
            <td>${flight.origin}</td>
            <td> ${flight.date}</td>
            <td>${flight.hour}</td>
            <td> ${flight.terminal}</td>
        </tr>`;
    });

    console.log(flight);
    flightList.innerHTML = flight;
}

async function addNewFlight() {
    event.preventDefault(); // Prevent the default form submission behavior

    // Get the form data
    const destination = document.getElementById('destination').value;
    const origin = document.getElementById('origin').value;
    const date = document.getElementById('date').value;
    const hour = document.getElementById('hour').value;
    const terminal = document.getElementById('terminal').value;

    // Create the flight object
    const flight = {
        destination,
        origin,
        date,
        hour,
        terminal
    };

    try {
        const response = await fetch('/flight', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(flight),
        });

        if (response.ok) {
            // Flight added successfully, show a message or update the flight list
            console.log('Flight added successfully!');
            fetchFlight(); // Fetch the updated flight list
        } else {
            console.error('Failed to add flight:', response.statusText);
        }
    } catch (error) {
        console.error('Error adding flight:', error);
    }
}

// Event listener to handle form submission
document.getElementById('flightForm').addEventListener('submit', addNewFlight);

// Function to fetch flights from the server and display them in the table
async function fetchFlight() {
    const response = await fetch('/flight');
    const data = await response.json();

    const flightList = document.getElementById('flightList');
    flightList.innerHTML = '';

    data.forEach((flight) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${flight.destination}</td>
            <td>${flight.origin}</td>
            <td>${flight.date}</td>
            <td>${flight.hour}</td>
            <td>${flight.terminal}</td>
        `;
        flightList.appendChild(row);
    });
}

// Fetch flights when the page loads
fetchFlight();


// Call the createSparkles function when the page loads




// morshirin23
// 59daJAH20rHceGRF