const express = require('express') 
const app = express()
const port = 3000 
app.use(express.static('public')) 
app.get('/form -data', (req, res) => { res.send('Hello World!') })
app.listen(port, () => {
console.log(`listening on http://localhost:${port}`)})

let selectedCategory = '';

function setCategory(category) {
  selectedCategory = category;
}

function runScript() {
  if (selectedCategory === '') {
    alert('Please select a category first.');
    return;
  }

  // Replace the code below with your desired VSCode script
  console.log(`Running script for ${selectedCategory}`);
}


