const fetchFunction = (html) => {
    fetch(html)
        .then(response => response.text())
        .then(htmlContent => {
            document.getElementById('body').innerHTML = htmlContent
        });

}

async function fetchFlight(){
    const response = await fetch('/flight');
    const data = await response.json()

    const flightList = document.getElementById('flightList');
    flightList.innerHTML= ``
    let flight =''

    data.forEach((flight) => {
        flight += `<tr>
    <td> ${flight.destination}</td>
    <td>${flight.origin}</td>
    <td> ${flight.date}</td>
    <td>${flight.hour}</td>
    <td> ${flight.terminal}</td>
   </td>
  </tr>`})
  console.log(flight);

  flightList.innerHTML=flight


}


// html -> file name


// morshirin23
// 59daJAH20rHceGRF